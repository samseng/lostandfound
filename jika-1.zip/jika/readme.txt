﻿===Lost And Found Web Apps===
Team-Name:지카
Contributors: 
->Mohd Nur Hafiz (2015057483)
->Norhaziqah Binti Manap (2015057474)
->Ernest Nyelang (2015057501)
->Adriana Nadhirah Ismail (2015057492)
Teacher: Prof. Scott UK-Jin Lee
Version:1.0
Date:15/12/2017
=============================

===How To Instructions====
1.Change all .txt file that is not readme to .js files.
2.Make a new database called 'lnf' in MAMP PHPMYADMIN.
3.Import the 'lnf.sql' file in the 'jika' folder in the 'lnf' database.
4.Then, open the 'frontpage.php' by writing 'localhost/jika/frontpage.php'.
5.In frontpage.php, there's link to other page:

++++++Search Page++++++
* To search, fill in the 'Searching for missing item' in 'frontpage.php' and click Go.
* It will search by title, and display title, and contact for the item.
* Click on categories list in the left to narrow down the search by category.
* Additional infos: If you want to search for all, do not input anything and click on 'Go' button.

++++++Upload page++++++
* Click on 'Upload item' button in 'frontpage.php'.
* Uploader's ID allowed input: 10 digit only.
* Item Name allowed input: alphabet only.
* Contact No: 11 digit only or email.
* Category: Choose from list.

+++++++Delete Page++++++++++
* Insert student ID inside the 'Student number' field/text box in 'frontpage.php'.
* Click the 'Search item' button and it will link to the page.
* Then double-click the 'Delete' button to delete the item from database.
* If the delete page is buggy, refresh the page.


