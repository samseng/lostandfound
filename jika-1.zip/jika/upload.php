<!DOCTYPE html>
<head>
	<title>Upload Form</title>
	<link rel="stylesheet" type="text/css" href="upload.css" />
	<link href="img/favicon.png" type="image/png" rel="shortcut icon" />
	<script src="prototype.js" type="text/javascript"></script>
	<script src="delete.js" type="text/javascript"></script>
</head>

<body>
		<div class="section1" id='banner'>
			<img src="img/logo.png" alt="logo" />
			<h1>Lost & Found</h1>
			<h6>ONLINE CENTER</h6>
		</div>

		<div class="overall">
		<div class="floatright">

		<div class="Title">
			<img src="img/favicon.png" alt="logo" />Forms
		</div>

		<div class="form-section">
			<p>Please fill in this details properly.</p>
			
				<div id='form'>
					<form action="" method="post" enctype="multipart/form-data">
						<ul>
							<li>Uploader's ID : </li>
							<input type="text" name="id" size="20" maxlength="10" placeholder="Student ID/Staff ID"/>
							<li>Choose image file:</li>
							<input type="file" name="file" accept=".jpg, .jpeg, .png, .gif" /> </br>
							<li>Item Name :</li>
							<input type="text" name="item" size="20" maxlength="15" placeholder="Title"/>
							<li>Contact No : </li>
							<input type="text" name="no" size="20" placeholder="Phone Number/Email"/>
							<li>Category : </li>
							<select name="tag">
			  				<option selected="selected">Electronics</option>
			  				<option>Bags</option>
			  				<option>Books</option>
			  				<option>Others</option>
							</select>
						</ul>

						<div id="submitbutton">
							<input type="submit" name="upload" value="Upload" />	
						</div>
					</form>
				</div>
			
		</div>

	<?php
	$username="root";
	$password="root";
	$database="lnf";

    //database handling sides.
    // Create connection
	$conn = mysqli_connect("localhost", $username, $password,$database);

    // Check connection
	if (!$conn) {
 	      die("Connection failed: " . mysqli_connect_error());
 	   }

	if(isset($_POST['upload']))
{
	
	if(!isset($_POST["id"]) || $_POST["id"] == "" || !isset($_POST["item"]) || $_POST["item"] == "" 
	|| !isset($_POST["no"]) || $_POST["no"] == "" || !isset($_POST["tag"]) || $_POST["tag"] == "" ){
		echo "<script type='text/javascript'>alert('You didnt fill out the form correctly!')</script>";
	} 
	elseif (!preg_match('/^[a-zA-Z]+(-[a-zA-Z]+)*([\s]?[a-zA-Z]+(-[a-zA-Z]+)*)?$/', $_POST["item"])){
		echo "<script type='text/javascript'>alert('Item must use alphabets only!')</script>";	
	} 
	elseif (!preg_match('/^[0-9]{10}$/', $_POST['id'])){
		echo "<script type='text/javascript'>alert('ID must use 10 digits numberic only!')</script>";
	}
	elseif ((!preg_match('/^[0-9]{11}$/', $_POST['no'])) && (!filter_var($_POST['no'], FILTER_VALIDATE_EMAIL))){
		echo "<script type='text/javascript'>alert('Phone Number or Email is invalid!')</script>";
	}
	else{
	

	//added item for file and move the file to upload image.
	$item_name = $_POST['item'];
	$contact_no = $_POST['no'];
	$uploader_id = $_POST['id'];
	$category = $_POST['tag'];
	$file = rand(1000,100000)."-".$_FILES['file']['name'];
 	$file_loc = $_FILES['file']['tmp_name'];
 	$folder="post/";

 	move_uploaded_file($file_loc,$folder.$file);
	echo " $category";
	$image = 'test';

	$sql="INSERT INTO item(title,category,image) VALUES('$item_name','$category','$file')";
	if (mysqli_query($conn, $sql)) {
		echo "<script type='text/javascript'>alert('You item have been uploaded')</script>";
} else {
    echo " Error: " . $sql . "<br>" . mysqli_error($conn);
}

$sqlcheck="SELECT * FROM uploader WHERE id='".$uploader_id."'";
$result_set=mysqli_query($conn,$sqlcheck);
$num_rows = mysqli_num_rows($result_set);

if($num_rows == 0){
$sql="INSERT INTO uploader(id,contact_no) VALUES('$uploader_id','$contact_no')";
	if (mysqli_query($conn, $sql)) {
} else {
    echo " Error: " . $sql . "<br>" . mysqli_error($conn);
}
}elseif($num_rows > 0){
	$sqlupdate = "UPDATE uploader SET contact_no='$contact_no' WHERE id='".$uploader_id."'";
	if (mysqli_query($conn, $sqlupdate)) {
} else {
    echo " Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

$sql="SELECT max(id) FROM item";
 $result_set=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($result_set))
 {
 	echo $row['max(id)'];
 	$item_id = $row['max(id)'];
 	}

$sql="INSERT INTO post(image_id,uploader_id) VALUES('$item_id','$uploader_id')";
	if (mysqli_query($conn, $sql)) {
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}
}
 ?>
	</div> <!-- Float right end -->
	</div>
</body>
</html>